#define STRICT
#include <windows.h>
#include <stdlib.h>
#include "ex9.rh"

LRESULT CALLBACK FrameWndProc  (HWND, UINT, WPARAM, LPARAM) ;
LRESULT CALLBACK RectWndProc  (HWND, UINT, WPARAM, LPARAM) ;
int CALLBACK AboutDlgProc (HWND , UINT , WPARAM , LPARAM );
int CALLBACK SizeDlgProc (HWND hDlg, UINT iMsg, WPARAM wParam, LPARAM lParam);


BOOL CALLBACK CloseEnumProc (HWND hwnd, LPARAM lParam)
     {
     if (GetWindow (hwnd, GW_OWNER))         // Check for icon title
          return 1 ;

     SendMessage (GetParent (hwnd), WM_MDIRESTORE, (WPARAM) hwnd, 0) ;

     if (!SendMessage (hwnd, WM_QUERYENDSESSION, 0, 0))
          return 1 ;

     SendMessage (GetParent (hwnd), WM_MDIDESTROY, (WPARAM) hwnd, 0) ;
          return 1 ;
     }




CRITICAL_SECTION lpCriticalSection 	;
char      szFrameClass[] = "Frame" ;
char      szRWClass[] = "RWChild" ;
HINSTANCE hInst ;
HMENU     hMenuInit, hMenuWithWindow ;
HMENU     hMenuInitWindow, hMenuSubMenuWindow;

static int windowscounter=0;

int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
                    PSTR szCmdLine, int iCmdShow)
     {
     HACCEL      hAccel ;
     HWND        hwndFrame, hwndMenager ;
     MSG         msg ;
     WNDCLASSEX  wndclass ;

     hInst = hInstance ;

     if (!hPrevInstance)
          {
                    // Register the frame window class

          wndclass.cbSize        = sizeof (wndclass) ;
          wndclass.style         = CS_HREDRAW | CS_VREDRAW ;
          wndclass.lpfnWndProc   = FrameWndProc ;
          wndclass.cbClsExtra    = 0 ;
          wndclass.cbWndExtra    = 0 ;
          wndclass.hInstance     = hInstance ;
          wndclass.hIcon         = LoadIcon (NULL, IDI_APPLICATION) ;
          wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW) ;
          wndclass.hbrBackground = (HBRUSH) (COLOR_APPWORKSPACE + 1) ;
          wndclass.lpszMenuName  = NULL ;
          wndclass.lpszClassName = szFrameClass ;
          wndclass.hIconSm       = LoadIcon (NULL, IDI_APPLICATION) ;

          RegisterClassEx (&wndclass) ;

          wndclass.cbSize        = sizeof (wndclass) ;
          wndclass.style         = CS_HREDRAW | CS_VREDRAW ;
          wndclass.lpfnWndProc   = RectWndProc ;
          wndclass.cbClsExtra    = 0 ;
          wndclass.cbWndExtra    = 4 ;����� ��������������� ������ �����
          wndclass.hInstance     = hInstance ;
          wndclass.hIcon         = LoadIcon (hInst, "IDI_ICON1") ;
          wndclass.hCursor       = LoadCursor (hInst, "IDC_CURSOR") ;
          wndclass.hbrBackground = (HBRUSH) GetStockObject (WHITE_BRUSH) ;
          wndclass.lpszMenuName  = NULL ;
          wndclass.lpszClassName = szRWClass ;
          wndclass.hIconSm       = LoadIcon (hInst, "IDI_ICON1" /*NULL, IDI_APPLICATION*/) ;

          RegisterClassEx (&wndclass) ;


     hMenuInit  = LoadMenu (hInst, "IDM_MENUMAIN") ;
     hMenuWithWindow = LoadMenu (hInst, "IDM_MENUWINDOW") ;

     hMenuInitWindow  = GetSubMenu (hMenuInit,  3) ;
     hMenuSubMenuWindow = GetSubMenu (hMenuWithWindow, 3) ;

		InitializeCriticalSection(&lpCriticalSection);

     hwndFrame = CreateWindow (szFrameClass, "MDI Complex problems",
                               WS_OVERLAPPEDWINDOW | WS_CLIPCHILDREN,
                               CW_USEDEFAULT, CW_USEDEFAULT,
                               CW_USEDEFAULT, CW_USEDEFAULT,
                               NULL, hMenuInit, hInstance, NULL) ;

     hwndMenager = GetWindow (hwndFrame, GW_CHILD) ;

     ShowWindow (hwndFrame, iCmdShow) ;
     UpdateWindow (hwndFrame) ;

               // Enter the modified message loop

     while (GetMessage (&msg, NULL, 0, 0))
          {
               TranslateMessage (&msg) ;
               DispatchMessage (&msg) ;
          }

     DestroyMenu (hMenuWithWindow) ;
		DeleteCriticalSection(&lpCriticalSection);
     }
     return msg.wParam ;

}




LRESULT CALLBACK FrameWndProc (HWND hwnd, UINT iMsg, WPARAM wParam,
                                                     LPARAM lParam)
     {
     static HWND         hwndMenager ;
     CLIENTCREATESTRUCT  clientcreate ;
     HWND                hwndChild ;
     MDICREATESTRUCT     mdicreate ;

     switch (iMsg)
          {
          case WM_CREATE :          // Create the client window ���� ���������

               clientcreate.hWindowMenu  = hMenuInitWindow ;
               clientcreate.idFirstChild = IDM_FIRSTCHILD ;

               hwndMenager = CreateWindow ("MDICLIENT", NULL,
                              WS_CHILD | WS_CLIPCHILDREN | WS_VISIBLE,
                              0, 0, 0, 0, hwnd, (HMENU) 1, hInst,
                              (LPSTR) &clientcreate) ;
               return 0 ;
          case WM_COMMAND :
               switch (wParam)
                    {
                    case 101:{
                         mdicreate.szClass = szRWClass ;
EnterCriticalSection(&lpCriticalSection);
									windowscounter++;
                           char * tmp = (char*)malloc(255);
                           wsprintf(tmp,"Rectangle Window (New command No[%i] passed)",windowscounter);
                         mdicreate.szTitle =  tmp;
LeaveCriticalSection(&lpCriticalSection);
                         mdicreate.hOwner  = hInst ;
                         mdicreate.x       = CW_USEDEFAULT ;
                         mdicreate.y       = CW_USEDEFAULT ;
                         mdicreate.cx      = CW_USEDEFAULT ;
                         mdicreate.cy      = CW_USEDEFAULT ;
                         mdicreate.style   = 0 ;
                         mdicreate.lParam  = (LPARAM)tmp ; ����� ���������� ��������� �� ������ ����������� ���������

                         hwndChild = (HWND) SendMessage (hwndMenager,
                                        WM_MDICREATE, 0,
                                        (LPARAM) (LPMDICREATESTRUCT) &mdicreate) ;
                         return 0 ;
                              }
/*
                    case IDM_CLOSE :

                         hwndChild = (HWND) SendMessage (hwndMenager,
                                                  WM_MDIGETACTIVE, 0, 0) ;

                         if (SendMessage (hwndChild, WM_QUERYENDSESSION, 0, 0))
                              SendMessage (hwndMenager, WM_MDIDESTROY,
                                           (WPARAM) hwndChild, 0) ;
                         return 0 ;
*/
                    case 108 :
                         SendMessage (hwnd, WM_CLOSE, 0, 0) ;
                         return 0 ;

                    case 301 :
                         SendMessage (hwndMenager, WM_MDITILE, 0, 0) ;
                         return 0 ;

                    case 302 :
                         SendMessage (hwndMenager, WM_MDICASCADE, 0, 0) ;
                         return 0 ;

                    case 303 :
                         SendMessage (hwndMenager, WM_MDIICONARRANGE, 0, 0) ;
                         return 0 ;

                    case 304 :
                         EnumChildWindows (hwndMenager, CloseEnumProc, 0) ;
                         return 0 ;
                    case 903:
                       DialogBox (hInst, "IDD_DIALOG", hwnd, AboutDlgProc) ;
                       return 0;
                    case CM_POPUPITEM5:
		                 hwndChild = (HWND) SendMessage (hwndMenager,
                                      WM_MDIGETACTIVE, 0, 0) ;

                       DialogBoxParam (hInst, "IDD_DIALOG1", hwnd, SizeDlgProc,(LPARAM)hwndChild);
                       return 0;


                    default :

                         hwndChild = (HWND) SendMessage (hwndMenager,
                                                  WM_MDIGETACTIVE, 0, 0) ;

                        if (IsWindow (hwndChild))
                             SendMessage (hwndChild, WM_COMMAND,
                                          wParam, lParam) ;

                        break ;
                    }
               break ;

          case WM_QUERYENDSESSION :
          case WM_CLOSE :

               SendMessage (hwnd, WM_COMMAND, 304, 0) ;

               if (NULL != GetWindow (hwndMenager, GW_CHILD))
                    return 0 ;

               break ;   // I.e., call DefFrameProc

          case WM_DESTROY :
               PostQuitMessage (0) ;
               return 0 ;
          }
               // Pass unprocessed messages to DefFrameProc (not DefWindowProc)

     return DefFrameProc (hwnd, hwndMenager, iMsg, wParam, lParam) ;
     }



LRESULT CALLBACK RectWndProc (HWND hwnd, UINT iMsg, WPARAM wParam,
                                                        LPARAM lParam)
     {
     static HWND     hwndMenager, hwndFrame ;
     HDC             hdc ;
     HMENU           hMenu ;
     RECT            Rect ;
     PAINTSTRUCT ps;
     int a;
     float koefficient;
     static int IndividualParameter;

     switch (iMsg)
          {
          case WM_CREATE :{
					CREATESTRUCT cs = *((CREATESTRUCT *)lParam);�������� ��������� �����������, � ��� ���� � ���������� �� ������ ���������
               SetWindowLong (hwnd, 0, ((LPMDICREATESTRUCT)(cs.lpCreateParams))->lParam) ;
                       � ����������� ������ ����� ������ ���������
                       (��� ������� ������ ������������� ������� ����� ���������)
               IndividualParameter = 3;���� �������� � ���� ���� �������
               hwndMenager = GetParent (hwnd) ;
               hwndFrame  = GetParent (hwndMenager) ;
               return 0 ;
               }

          case WM_PAINT :
                         // Paint the window

               hdc = BeginPaint (hwnd, &ps) ;

               GetClientRect (hwnd, &Rect) ;
               switch(IndividualParameter){
               	case 1:
							koefficient = .4;break;������ ������� ������������� ����� ���� ����� ��������� ��� �� ��������, ������� ����� ������� �� ��������� � ������������
                  case 2:
							koefficient = .25;break;
                  case 3:
							koefficient = .1;
               }
            a=Rect.bottom * koefficient;
            Rect.top+=a;
            Rect.bottom-=a;
            a=Rect.right * koefficient;
            Rect.left+=a;
          	Rect.right-=a;
            FrameRect(
			    hdc,
			    &Rect,
			    (HBRUSH)GetStockObject(LTGRAY_BRUSH));
               EndPaint (hwnd, &ps) ;
               return 0 ;

          case WM_MDIACTIVATE :
               if (lParam == (LPARAM) hwnd)
                    SendMessage (hwndMenager, WM_MDISETMENU,
                               (WPARAM) hMenuWithWindow, (LPARAM) hMenuSubMenuWindow) ;

               if (lParam != (LPARAM) hwnd)
                    SendMessage (hwndMenager, WM_MDISETMENU, (WPARAM) hMenuInit,
                                 (LPARAM) hMenuInitWindow) ;

               DrawMenuBar (hwndFrame) ;
               return 0 ;
          case WM_USER:
          	switch(wParam){
            	case 0://������ ������� �������� ������� ��������������
               return IndividualParameter;break;� ����� � ����� ������ ��������������� ��������� ������������ ��� ���������� ���������� �� ���������
               case 1:
               IndividualParameter = LOWORD(lParam);
               InvalidateRect(hwnd,NULL,TRUE);
               return 0;
            }

          case WM_QUERYENDSESSION :
          case WM_CLOSE :
               if (IDYES != MessageBox (hwnd, "Are you shure ?", "RectangleWindow",
                                       MB_ICONQUESTION | MB_YESNO))
                    return 0 ;

               break ;   // I.e., call DefMDIChildProc

          case WM_DESTROY :{
					char * ptr =(char *)GetWindowLong (hwnd, 0) ;
               free(ptr);�� ������ �� ����� ���������� ����������������� ������
               return 0 ; �� ��������� ������ ��������
               }
          }
               // Pass unprocessed message to DefMDIChildProc

     return DefMDIChildProc (hwnd, iMsg, wParam, lParam) ;
     }


int CALLBACK AboutDlgProc (HWND hDlg, UINT iMsg, WPARAM wParam, LPARAM lParam)
     {
     switch (iMsg)
          {
          case WM_INITDIALOG :
               return TRUE ;

			case WM_CLOSE:
          case WM_COMMAND :
               switch (LOWORD (wParam))
                    {
		            case IDOK :
                         EndDialog (hDlg, 0) ;
			             return TRUE ;
                    }
               break ;
          }
     return FALSE ;
}

int CALLBACK SizeDlgProc (HWND hDlg, UINT iMsg, WPARAM wParam, LPARAM lParam)
     {
static int current;
static HWND hWndActiveClient;
     switch (iMsg)
          {
          case WM_INITDIALOG :
          		hWndActiveClient = (HWND)lParam;
          		current = 1024+SendMessage (hWndActiveClient,WM_USER, 0, 0);
               CheckRadioButton (hDlg, 1025,1027, current) ;
               return FALSE ;

			case WM_CLOSE:
              EndDialog (hDlg, 0) ;
             return TRUE ;
         case WM_COMMAND :
               switch (LOWORD (wParam))
                    {
		            case 1025 :
                  case 1026 :
                  case 1027 :
                  	SendMessage(hWndActiveClient,WM_USER,1,LOWORD (wParam)-1024);
                     return TRUE;
                  case IDOK:
                     EndDialog (hDlg, 0) ;
			             return TRUE ;
                    }
               break ;
          }
     return FALSE ;
}
